import React, { Component } from 'react';
import './App.css';
import Header from './Header.js'
import Article from './Article.js'
class App extends Component {

  render() {
    return (
      <div className="App">
        <div className="mainContainer">
          <div className="appContainer">
           <Header/>
           <Article/>
          </div>
        </div>
      </div>
    );
  }
}

export default App;
