
import React from 'react';
import { expect } from 'chai';
import { shallow } from 'enzyme';
import App from './App';


describe('<App />', () => {
  let wrapper
  beforeAll(() => {

    wrapper = shallow(<App />);
  });
  it('render without exploding', () => {

    expect(wrapper).to.have.length(1);
  });
  it('App should be present', () => {
    expect(wrapper.find('.App')).to.have.lengthOf(1);
  });
  it('mainContainer should be present', () => {
    expect(wrapper.find('.mainContainer')).to.have.lengthOf(1);
  });
  it('appContainer should be present', () => {
    expect(wrapper.find('.appContainer')).to.have.lengthOf(1);
  });
  it('Header component should be present', () => {
    expect(wrapper.find('Header')).to.have.lengthOf(1);
  });
  it('Article component should be present', () => {
    expect(wrapper.find('Article')).to.have.lengthOf(1);
  });

});
