import React, { Component } from 'react';
import './Article.css';
import { articleData } from './articleData.js'
class Article extends Component {

   
    eachArticle = () => {
        return articleData && articleData.map((article , index) => {
            return (
                <div className="eachtripDestination" key ={index}>
                    <div className="eachtripDestinationImage">
                        <img className="destinationImage" src={article.destinationImage} alt="destination pic" />
                    </div>
                    <div className="leftDestinationInfo">
                        <div className="destinationName">{article.destinationName}</div>
                        <div className="description">{article.description}</div>
                        <div className="destinationStartEOperator">
                            <div className="destination">
                                <div className="textLabel">{article.textLabel1}</div>
                                <div className="textValue">{article.textValue1}</div>
                            </div>
                            <div className="startEnd">
                                <div className="textLabel">{article.textLabel1}</div>
                                <div className="textValue">{article.textValue2}</div>
                            </div>
                            <div className="operator">
                                <div className="textLabel">{article.textLabel3}</div>
                                <div className="textValue">{article.textValue3}</div>
                            </div>
                        </div>
                    </div>
                    <div className="rightDestinationInfo">
                        <div className="leftSideDestinationInfo">
                            <div className="destinationPriceAndDiscount">
                                <div className="startFromLabel">From</div>
                                € <span className="finalPrice">{article.finalPrice}</span>
                                <div className="priceDiscount"> <strike>{article.priceDiscount}</strike> <span className="discountValue">{article.discountValue}</span></div>
                            </div>
                            <div className="noOfDays">{article.noOfDays}<span className="daysLabel">days</span></div>
                        </div>
                        <div className="rightSideDestinationInfo">
                            <div className="dateAndSpaces">
                                <div className="startsFromContainer">
                                    <div className="startFrom">{article.startFrom1}<span className="onlyLeft">{article.onlyLeft1}</span></div>
                                    <div className="startFrom">{article.startFrom2}<span className="onlyLeft">{article.onlyLeft2}</span></div>
                                </div>
                            </div>
                            <div className="viewMoreButton"><button className="btn-success">View More</button></div>
                        </div>
                    </div>
                    <hr />
                </div>
            )
        })

    }
    render() {
        return (

            <div className="articles">
                {this.eachArticle()}
            </div>

        )
    }
}

export default Article;
