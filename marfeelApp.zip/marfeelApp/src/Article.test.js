
import React from 'react';
import { expect } from 'chai';
import { shallow } from 'enzyme';
import Article from './Article';

describe('<Article />', () => {
  let wrapper
  beforeAll(() => {

    wrapper = shallow(<Article />);
  });
  it('render without exploding', () => {
    expect(wrapper).to.have.length(1);
  });
  it('eachtripDestination should be present', () => {
    expect(wrapper.find('.eachtripDestination')).to.have.lengthOf(5);
  });
  it('eachtripDestinationImage should be present', () => {
    expect(wrapper.find('.eachtripDestinationImage')).to.have.lengthOf(5);
  });
  it('img should be present', () => {
    expect(wrapper.find('img')).to.have.lengthOf(5);
  });
  it('destinationImage should be present', () => {
    expect(wrapper.find('.destinationImage')).to.have.lengthOf(5);
  });


  it('leftDestinationInfo should be present', () => {
    expect(wrapper.find('.leftDestinationInfo')).to.have.lengthOf(5);
  });
  it('destinationName should be present', () => {
    expect(wrapper.find('.destinationName')).to.have.lengthOf(5);
  });
  it('description should be present', () => {
    expect(wrapper.find('.description')).to.have.lengthOf(5);
  });
  it('destinationStartEOperator should be present', () => {
    expect(wrapper.find('.destinationStartEOperator')).to.have.lengthOf(5);
  });


  it('destination should be present', () => {
    expect(wrapper.find('.destination')).to.have.lengthOf(5);
  });
  it('textLabel should be present', () => {
    expect(wrapper.find('.textLabel')).to.have.lengthOf(15);
  });
  it('textValue should be present', () => {
    expect(wrapper.find('.textValue')).to.have.lengthOf(15);
  });
  it('startEnd should be present', () => {
    expect(wrapper.find('.startEnd')).to.have.lengthOf(5);
  });
  it('operator should be present', () => {
    expect(wrapper.find('.operator')).to.have.lengthOf(5);
  });



  it('rightDestinationInfo should be present', () => {
    expect(wrapper.find('.rightDestinationInfo')).to.have.lengthOf(5);
  });
  it('leftSideDestinationInfo should be present', () => {
    expect(wrapper.find('.leftSideDestinationInfo')).to.have.lengthOf(5);
  });
  it('destinationPriceAndDiscount should be present', () => {
    expect(wrapper.find('.destinationPriceAndDiscount')).to.have.lengthOf(5);
  });
  it('startFromLabel should be present', () => {
    expect(wrapper.find('.startFromLabel')).to.have.lengthOf(5);
  });

  it('finalPrice should be present', () => {
    expect(wrapper.find('.finalPrice')).to.have.lengthOf(5);
  });
  it('priceDiscount should be present', () => {
    expect(wrapper.find('.priceDiscount')).to.have.lengthOf(5);
  });
  it('discountValue should be present', () => {
    expect(wrapper.find('.discountValue')).to.have.lengthOf(5);
  });
  it('noOfDays should be present', () => {
    expect(wrapper.find('.noOfDays')).to.have.lengthOf(5);
  });


  it('daysLabel should be present', () => {
    expect(wrapper.find('.daysLabel')).to.have.lengthOf(5);
  });
  it('rightSideDestinationInfo should be present', () => {
    expect(wrapper.find('.rightSideDestinationInfo')).to.have.lengthOf(5);
  });
  it('dateAndSpaces should be present', () => {
    expect(wrapper.find('.dateAndSpaces')).to.have.lengthOf(5);
  });
  it('startsFromContainer should be present', () => {
    expect(wrapper.find('.startsFromContainer')).to.have.lengthOf(5);
  });

  it('startFrom should be present', () => {
    expect(wrapper.find('.startFrom')).to.have.lengthOf(10);
  });
  it('onlyLeft should be present', () => {
    expect(wrapper.find('.onlyLeft')).to.have.lengthOf(10);
  });
  it('viewMoreButton should be present', () => {
    expect(wrapper.find('.viewMoreButton')).to.have.lengthOf(5);
  });


});
