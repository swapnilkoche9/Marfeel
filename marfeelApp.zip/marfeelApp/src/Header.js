import React, { Component } from 'react';
import './Header.css';
import { Nav } from 'react-bootstrap';
import { HeaderNavData } from './HeaderData.js'
import logo from './marfeel.svg'
let button
class Header extends Component {

  constructor(props) {
    super(props)
    this.state = { showNav: true, showonlyBurger: false }
  }
  componentDidMount() {
    window.addEventListener('scroll', this.handleScroll)
    button = document.getElementById('hamburger-menu')
    button.addEventListener('click', this.handleButtonClick)
  }

  componentWillUnmount() {
    window.removeEventListener('scroll', this.handleScroll);
    button = document.getElementById('hamburger-menu')
  }
  getHeaderNav = () => {
    return HeaderNavData.map((nav,index) => {
      return (
        <Nav.Item key={index}>
          <Nav.Link href={nav.link} eventKey={nav.eventKey}>{nav.name}</Nav.Link>
        </Nav.Item>
      )
    })
  }
  handleButtonClick = () => {
    var element = document.getElementById("nav");
    element.classList.toggle("on");
    let span = button.getElementsByTagName('span')[0]
    span.classList.toggle('hamburger-menu-button-close')

  }
  handleScroll = () => {

    if (window.pageYOffset >= 400 && window.pageYOffset < 800) {
      this.setState({ showNav: false, showonlyBurger: false })
    } else if (window.pageYOffset >= 800) {
      this.setState({ showonlyBurger: true, showNav: false })
    }
    else {
      this.setState({ showNav: true, showonlyBurger: false })
    }
  }


  render() {
    return (
      <div className="mainHeader">

        <nav id="nav" className="ham-menu">
          <ul className="menu">
            <li><a href="#">Section1</a></li>
            <li><a href="#">Section2</a></li>
            <li><a href="#">Section3</a></li>
          </ul>
        </nav>
        <div className="headerTopSection">
          <div className="hamburgerMenu">
            <button id="hamburger-menu" data-toggle="ham-navigation" className="hamburger-menu-button"><span className="hamburger-menu-button-open">Menu</span></button>
          </div>
          {!this.state.showonlyBurger ? <div className="logo">
            <img src={logo} />
          </div> : ''}
        </div>
        {this.state.showNav ? <div className="headerBottomSection">

          <Nav id="navBar" variant="pills" defaultActiveKey="/home">
            {this.getHeaderNav()}
          </Nav>
        </div> : ''}
      </div>
    )
  }
}

export default Header;
