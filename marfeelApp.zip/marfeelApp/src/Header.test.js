
import React from 'react';
import { expect } from 'chai';
import { shallow, mount } from 'enzyme';
import Header from './Header';

describe('<Header />', () => {
    describe('<Header /> with initial state', () => {
        let wrapper
        beforeAll(() => {
            wrapper = shallow(<Header />);
            wrapper.setState({ showNav: true, showonlyBurger: false })
        });
        it('render without exploding', () => {
            expect(wrapper).to.have.length(1);
        });
        it('state should set in component', () => {
            expect(wrapper.instance().state.showNav).equal(true);
            expect(wrapper.instance().state.showonlyBurger).equal(false);
        });

        it('sections should be visible on click of hamburger', () => {
            const wrapper1 = shallow(<Header window={window} />);
            const button = wrapper1.find('button');
            button.simulate('click');
            expect(wrapper1.find('.on')).to.have.lengthOf(0);

        });




        it('ham-menu should not be present', () => {
            expect(wrapper.find('.ham-menu')).to.have.lengthOf(1);
        });
        it('headerTopSection should be present', () => {
            expect(wrapper.find('.headerTopSection')).to.have.lengthOf(1);
        });
        it('hamburgerMenu should be present', () => {
            expect(wrapper.find('.hamburgerMenu')).to.have.lengthOf(1);
        });
        it('hamburger-menu-button-open should be present', () => {
            expect(wrapper.find('.hamburger-menu-button-open')).to.have.lengthOf(1);
        });


        it('img should be present', () => {
            expect(wrapper.find('img')).to.have.lengthOf(1);
        });


    });


    describe('<Header /> with different state', () => {
        let wrapper
        beforeAll(() => {
            wrapper = shallow(<Header />);
            wrapper.setState({ showNav: false, showonlyBurger: true })
        });
        it('render without exploding', () => {
            expect(wrapper).to.have.length(1);
        });
        it('state should set in component', () => {
            expect(wrapper.instance().state.showNav).equal(false);
            expect(wrapper.instance().state.showonlyBurger).equal(true);
        });

        it('sections should be visible on click of hamburger', () => {
            const wrapper1 = shallow(<Header window={window} />);
            const button = wrapper1.find('button');
            button.simulate('click');
            expect(wrapper1.find('.on')).to.have.lengthOf(0);

        });




        it('ham-menu should not be present', () => {
            expect(wrapper.find('.ham-menu')).to.have.lengthOf(1);
        });
        it('headerTopSection should be present', () => {
            expect(wrapper.find('.headerTopSection')).to.have.lengthOf(1);
        });
        it('hamburgerMenu should be present', () => {
            expect(wrapper.find('.hamburgerMenu')).to.have.lengthOf(1);
        });
        it('hamburger-menu-button-open should be present', () => {
            expect(wrapper.find('.hamburger-menu-button-open')).to.have.lengthOf(1);
        });


        it('img should not be present', () => {
            expect(wrapper.find('img')).to.have.lengthOf(0);
        });


    });



    describe('<Header /> with different state', () => {
        let wrapper
        beforeAll(() => {
            wrapper = shallow(<Header />);
            wrapper.setState({ showNav: false, showonlyBurger: false })
        });
        it('render without exploding', () => {
            expect(wrapper).to.have.length(1);
        });
        it('state should set in component', () => {
            expect(wrapper.instance().state.showNav).equal(false);
            expect(wrapper.instance().state.showonlyBurger).equal(false);
        });

        it('sections should be visible on click of hamburger', () => {
            const wrapper1 = shallow(<Header window={window} />);
            const button = wrapper1.find('button');
            button.simulate('click');
            expect(wrapper1.find('.on')).to.have.lengthOf(0);

        });




        it('ham-menu should not be present', () => {
            expect(wrapper.find('.ham-menu')).to.have.lengthOf(1);
        });
        it('headerTopSection should be present', () => {
            expect(wrapper.find('.headerTopSection')).to.have.lengthOf(1);
        });
        it('hamburgerMenu should be present', () => {
            expect(wrapper.find('.hamburgerMenu')).to.have.lengthOf(1);
        });
        it('hamburger-menu-button-open should be present', () => {
            expect(wrapper.find('.hamburger-menu-button-open')).to.have.lengthOf(1);
        });


        it('img should  be present', () => {
            expect(wrapper.find('img')).to.have.lengthOf(1);
        });


    });
});  
