export let HeaderNavData = [
    {
        "name":"HOME", 
        "link":'/home',
        
    },
    {
        "name":"POLITICS",
        "link":'' ,
        "eventKey":"POLITICS"
    },
    {
        "name":"OPINIONS", 
        "link":'',
        "eventKey":"OPINIONS" 
    },
    {
        "name":"SPORTS", 
        "link":'' ,
        "eventKey":"SPORTS" 
    },
    {
        "name":"NATION", 
        "link":'' ,
        "eventKey":"NATION" 
    },
    
]
